from rest_framework import serializers
#############################
from notifications.models import Notification
from rest_framework import serializers
from django.core.files.storage import default_storage
from django.core.files.storage import FileSystemStorage
import os
import cv2
import sys
from requestNotification.api.serializers import RNotificationSerializer
from requestNotification.models import RNotification
############################
class NotificationUpdateSerializer(serializers.ModelSerializer):
	class Meta:
		model = Notification
		fields = ('pk','status')

class NotificationSerializerUser(serializers.ModelSerializer):
	#user = serializers.PrimaryKeyRelatedField(read_only=True)
	senderNumber   = serializers.ReadOnlyField(source='senderid.mobile_number')
	senderLocation = serializers.ReadOnlyField(source='senderid.area')
	class Meta:
		model  = Notification
		fields = ('pk','message','donationLocation', 'status','receverid','senderid','senderNumber','senderLocation')

class NotificationSerializer(serializers.ModelSerializer):
	notify    = RNotificationSerializer(many=True)
	class Meta:
		model = Notification
		fields = ('pk','message','donationLocation', 'status','receverid','notify')

class  NotificationCreateSerializer(serializers.ModelSerializer):
	class Meta:
		model = Notification
		fields = ('message','donationLocation', 'status','receverid', 'senderid')
	def save(self):
		try:
			message                   = self.validated_data['message']
			donationLocation          = self.validated_data['donationLocation']
			status                    = self.validated_data['status']
			receverid_id              = self.validated_data['receverid']
			senderid                  = self.validated_data['senderid']
			notifications = Notification(    
				                message=message,
								donationLocation=donationLocation,
								status=status,
								receverid= receverid_id,
								senderid=senderid
								)
			notifications.save()
			return notifications
		except KeyError:
			raise serializers.ValidationError({"response": "this invalid somethings!!!!!"})