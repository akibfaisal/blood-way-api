from django.urls import path,include
from notifications.api import views
from notifications.api.views import(
      api_create_notification_view,
      api_update_notification_view,
      api_delete_notification_view,
      NotificationListView
)

app_name = 'notifications'

urlpatterns = [
   
    path('list', NotificationListView.as_view(), name="list"),
	path('create', api_create_notification_view, name="create"),
	path('update/<pk>', api_update_notification_view, name="update"),
	path('delete/<pk>',api_delete_notification_view, name ="delete")

]