from django.urls import path
from users.api.views import(
	registration_view,
	AccountListView,
	update_account_view,
	ObtainAuthTokenView,
	api_delete_person_view,
	api_update_notification_person_view,
	api_update_image_person_view,
	PersonalDetailView,
	AccountOnly,

)
app_name = 'users'

urlpatterns = [
	path('account/login', ObtainAuthTokenView.as_view(), name="login"), # -> see accounts/api/views.py for response and url info
	path('account/register', registration_view, name="register"),
	##############################################################
	path('account/list', AccountListView.as_view(), name='accountView'),
	#############################################################
    path('account/imageupdate/<pk>', api_update_image_person_view, name="update_image"),
	path('account/notificationupdate/<pk>', api_update_notification_person_view, name="update_notification"),
	path('account/delete/<pk>',api_delete_person_view, name ="delete"),
    path('account/<int:pk>', PersonalDetailView.as_view(), name=None),
    ##################################################################
    path('onlyaccount/list', AccountOnly.as_view(), name = "onlyaccount")
]

