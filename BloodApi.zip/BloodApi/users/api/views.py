from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from users.api.serializers import RegistrationSerializer, AccountSerializer,UpdatePersonimageSerializer,UpdateNotificationSerializer,OnlyAccountSerialiser
from users.models import CustomUser
from rest_framework.authtoken.models import Token
from . import serializers
from rest_framework import generics, status

###############################################
from rest_framework.generics import ListAPIView
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework import serializers
###############################################
SUCCESS = 'success'
ERROR = 'error'
DELETE_SUCCESS = 'deleted'
UPDATE_SUCCESS = 'updated'
CREATE_SUCCESS = 'created'
###############################################
@api_view(['DELETE',])
#@permission_classes((IsAuthenticated, ))
def api_delete_person_view(request, pk):

	try:
		info_user = CustomUser.objects.get(pk=pk)
	except CustomUser.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)


	if request.method == 'DELETE':
		operation = info_user.delete()
		data = {}
		if operation:
			data['response'] = DELETE_SUCCESS
		return Response(data=data)

@api_view(['PUT'])
#@permission_classes((IsAuthenticated, ))
def api_update_notification_person_view(request,pk):

	try:
		info_user = CustomUser.objects.get(pk=pk)
	except CustomUser.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'PUT':
		serializer = UpdateNotificationSerializer(info_user, data=request.data, partial=True)
		data = {}
		if serializer.is_valid():
			serializer.save()
			data['response'] = UPDATE_SUCCESS
			data['pk'] = info_user.pk
			return Response(data=data)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
@permission_classes((IsAuthenticated, ))
def api_update_image_person_view(request,pk):
	try:
		info_user = CustomUser.objects.get(pk=pk)
	except CustomUser.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'PUT':
		serializer = UpdatePersonimageSerializer(info_user, data=request.data, partial=True)
		data = {}
		if serializer.is_valid():
			serializer.save()
			data['response'] = UPDATE_SUCCESS
			data['pk'] = info_user.pk
			data['user_image'] = info_user.user_image
			return Response(data=data)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @permission_classes([])
# @authentication_classes([])
# class AccountCreateView(generics.CreateAPIView):
#     queryset = CustomUser.objects.all()
#     serializer_class = serializers.CustomRegs

#     def create(self, request, *args, **kwargs):
#         super(AccountCreateView, self).create(request, args, kwargs)
#         response = {"status_code": status.HTTP_200_OK,
#                     "message": "Successfully created",
#                     "result": request.data}
#         return Response(response)
# Register
# Response: https://gist.github.com/mitchtabian/c13c41fa0f51b304d7638b7bac7cb694
# Url: https://<your-domain>/api/account/register
@api_view(['POST', ])
@permission_classes([])
@authentication_classes([])
def registration_view(request):

	if request.method == 'POST':
		data = {}
		email = request.data.get('email', '0')
		if validate_email(email) != None:
			data['error_message'] = 'That email is already in use.'
			data['response'] = 'Error'
			return Response(data)

		username = request.data.get('username', '0')
		if validate_username(username) != None:
			data['error_message'] = 'That username is already in use.'
			data['response'] = 'Error'
			return Response(data)

		serializer = RegistrationSerializer(data=request.data)
		if serializer.is_valid():
			account = serializer.save()
			data['response'] = 'successfully registered new user.'
			data['pk'] = account.pk
			data['email'] = account.email
			data['username'] = account.username
			data['area'] = account.area
			data['city'] = account.city
			data['blood_group'] = account.blood_group
			data['age'] = account.age
			data['mobile_number'] = account.mobile_number
			data['status']    = account.status
			token = Token.objects.get(user=account).key
			data['token'] = token
		else:
			data = serializer.errors
		return Response(data)

def validate_email(email):
	account = None
	try:
		account = CustomUser.objects.get(email=email)
	except CustomUser.DoesNotExist:
		return None
	if account != None:
		return email

def validate_username(username):
	account = None
	try:
		account = CustomUser.objects.get(username=username)
	except CustomUser.DoesNotExist:
		return None
	if account != None:
		return username


# Account properties
# Response: https://gist.github.com/mitchtabian/4adaaaabc767df73c5001a44b4828ca5
# Url: https://<your-domain>/api/account/
# Headers: Authorization: Token <token>
@api_view(['GET', ])
@permission_classes((IsAuthenticated, ))
def account_properties_view(request):

	try:
		account = request.user
	except CustomUser.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'GET':
		serializer = AccountPropertiesSerializer(account)
		return Response(serializer.data)


# Account update properties
# Response: https://gist.github.com/mitchtabian/72bb4c4811199b1d303eb2d71ec932b2
# Url: https://<your-domain>/api/account/properties/update
# Headers: Authorization: Token <token>
@api_view(['PUT',])
@permission_classes((IsAuthenticated, ))
def update_account_view(request):

	try:
		account = request.user
	except CustomUser.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)
		
	if request.method == 'PUT':
		serializer = AccountPropertiesSerializer(account, data=request.data)
		data = {}
		if serializer.is_valid():
			serializer.save()
			data['response'] = 'Account update success'
			return Response(data=data)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# LOGIN
# Response: https://gist.github.com/mitchtabian/8e1bde81b3be342853ddfcc45ec0df8a
# URL: http://127.0.0.1:8000/api/account/login
class ObtainAuthTokenView(APIView):

	authentication_classes = []
	permission_classes = []

	def post(self, request):
		context = {}

		email = request.POST.get('username')
		password = request.POST.get('password')
		account = authenticate(email=email, password=password)
		#print(account)
		if account:
			try:
				token = Token.objects.get(user=account)
				#print(token)
			except Token.DoesNotExist:
				token = Token.objects.create(user=account)
			context['response'] = 'successfullylogin'
			#context['pk'] = account.mobile_number
			context['pk'] = account.pk
			context['email'] = email
			context['token'] = token.key
		else:
			context['response'] = 'Error'
			context['error_message'] = 'Invalid credentials'

		return Response(context)

#showing personalListView with 
@permission_classes((IsAuthenticated, ))
class  AccountListView(ListAPIView):
	queryset = CustomUser.objects.all()
	serializer_class = OnlyAccountSerialiser
	filter_backends = (SearchFilter, OrderingFilter)
	search_fields = ('blood_group',)

@permission_classes((IsAuthenticated, ))
class  AccountOnly(ListAPIView):
	queryset = CustomUser.objects.all()
	serializer_class = OnlyAccountSerialiser
	filter_backends = (SearchFilter, OrderingFilter)
	search_fields = ('blood_group', 'area', 'city')


    #in this method we are show list for single pk details 
class PersonalDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = AccountSerializer

    def retrieve(self, request, *args, **kwargs):
        super(PersonalDetailView, self).retrieve(request, args, kwargs)
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        data = serializer.data
        response = {"status_code": status.HTTP_200_OK,
                    "message": "successfully retrieved",
                    "result": data}
        return Response(response)
















