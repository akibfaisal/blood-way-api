from rest_framework import serializers
from users.models import CustomUser
from rest_framework import serializers
from django.core.files.storage import default_storage
from django.core.files.storage import FileSystemStorage
import os
import cv2
import sys
from notifications.api.serializers import NotificationSerializerUser

class UpdatePersonimageSerializer(serializers.ModelSerializer):
	class Meta:
		model = CustomUser
		fields = ('pk', 'user_image')

class UpdateNotificationSerializer(serializers.ModelSerializer):
	class Meta:
		model = CustomUser
		fields = ('pk', 'status')


class RegistrationSerializer(serializers.ModelSerializer):

	password2 				= serializers.CharField(style={'input_type': 'password'}, write_only=True)

	class Meta:
		model = CustomUser
		fields = ['email', 'username', 'password', 'password2','area', 'city', 'blood_group', 'age', 'mobile_number','user_image','status']
		extra_kwargs = {
				'password': {'write_only': True},
		}	
	def	save(self):

		account = CustomUser(
					email=self.validated_data['email'],
					username=self.validated_data['username'],
					area = self.validated_data['area'],
					city = self.validated_data['city'],
					blood_group = self.validated_data['blood_group'],
					age = self.validated_data['age'],
					mobile_number = self.validated_data['mobile_number']
				)
		password = self.validated_data['password']
		password2 = self.validated_data['password2']
		if password != password2:
			raise serializers.ValidationError({'password': 'Passwords must match.'})
		account.set_password(password)
		account.save()
		return account
class OnlyAccountSerialiser(serializers.ModelSerializer):
	class Meta:
		model = CustomUser
		fields = ['pk','email', 'username','area', 'city', 'blood_group', 'age', 'mobile_number','user_image','status']

class AccountSerializer(serializers.ModelSerializer):
	receverinfo = NotificationSerializerUser(many=True)
	class Meta:
		model = CustomUser
		fields = ['pk','email', 'username','area', 'city', 'blood_group', 'age', 'mobile_number','user_image', 'receverinfo', 'status']





