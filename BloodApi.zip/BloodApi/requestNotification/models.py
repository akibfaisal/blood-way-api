from django.db import models
from django.conf import settings
from notifications.models import Notification

class RNotification(models.Model):
	title            = models.CharField(max_length=15, null=True, blank=True)
	user             = models.OneToOneField(settings.AUTH_USER_MODEL, related_name='user_info', on_delete=models.CASCADE, null=True)
	notification     = models.ForeignKey(Notification, related_name='notify', on_delete=models.CASCADE, null=True)

	def __str__(self):
		return self.title

