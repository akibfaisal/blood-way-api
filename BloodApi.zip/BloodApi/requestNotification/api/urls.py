from django.urls import path,include
from requestNotification.api import views
from requestNotification.api.views import(
      api_create_requestnotification_view,
      api_update_requestnotification_view,
      api_delete_requestnotification_view,
      RNotificationListView
)

app_name = 'requestNotification'

urlpatterns = [
   
    path('list', RNotificationListView.as_view(), name="list"),
	path('create', api_create_requestnotification_view, name="create"),
	path('update/<pk>', api_update_requestnotification_view, name="update"),
	path('delete/<pk>',api_delete_requestnotification_view, name ="delete")

]