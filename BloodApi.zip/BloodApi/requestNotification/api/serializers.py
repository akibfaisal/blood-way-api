from rest_framework import serializers
#############################
from requestNotification.models import RNotification
from rest_framework import serializers
from django.core.files.storage import default_storage
from django.core.files.storage import FileSystemStorage
import os
import cv2
import sys
############################


class RNotificationUpdateSerializer(serializers.ModelSerializer):
	class Meta:
		model = RNotification
		fields = ('pk')

class RNotificationSerializer(serializers.ModelSerializer):
	class Meta:
		model = RNotification
		fields = ('pk','user', 'notification')

class  RNotificationCreateSerializer(serializers.ModelSerializer):
	class Meta:
		model = RNotification
		fields = ('user', 'notification')
	def save(self):
		try:
			user                      = self.validated_data['user']
			notification              = self.validated_data['notification']
			# status                    = self.validated_data['status']
			# receverid                 = self.validated_data['receverid']
			rnotifications = RNotification(    
				                user=user,
								notification=notification,
								#status=status,
								# receverid= receverid
								)
			rnotifications.save()
			return rnotifications
		except KeyError:
			raise serializers.ValidationError({"response": "this invalid somethings!!!!!"})