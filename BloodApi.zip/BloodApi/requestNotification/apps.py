from django.apps import AppConfig


class RequestnotificationConfig(AppConfig):
    name = 'requestNotification'
